<?php 

    header("location:Student_Form.php");

?>